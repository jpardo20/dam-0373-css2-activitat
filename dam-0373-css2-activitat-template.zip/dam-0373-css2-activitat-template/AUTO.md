
# AUTO — Autoavaluació (20 punts)

1) **Conflicte d’especificitat** que has creat expressament i com s’ha resolt (inclou el selector):  
…

2) On **hereta** el `font-family`? Quin estil **no** s’hereta? Per què?  
…

3) Com has evitat el problema del contenidor amb **floats**?  
…

4) Un possible **risc d’accessibilitat** i com el mitigaries amb CSS2:  
…

5) Quin **límit** té la maquetació sense Flex/Grid en pantalles petites?  
…
